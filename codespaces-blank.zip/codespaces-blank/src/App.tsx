import "./index.css";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { CountdownTimer } from "./components/CountdownTimer";
import { QuoteSection } from "./components/QuoteSection";
import { RSVPWishesSection } from "./components/RSVPWishesSection";
import { GallerySection } from "./components/GallerySection";
import weddingData from "./data/weddingData.json";

// Hook untuk mendeteksi apakah elemen sedang terlihat
function useScrollAnimation() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });
  
  return { ref, isInView };
}

// Komponen Hero Section
function HeroSection() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [buttonsVisible, setButtonsVisible] = useState(false);

  // Delay untuk menampilkan buttons setelah hero animation selesai
  useEffect(() => {
    const timer = setTimeout(() => {
      setButtonsVisible(true);
    }, 2000); // Delay 2 detik
    
    return () => clearTimeout(timer);
  }, []);

  const scrollToQuote = () => {
    const quoteSection = document.getElementById('quote-section');
    if (quoteSection) {
      quoteSection.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }
  };

  return (
    <motion.section 
      className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-b from-elegant-off-white via-elegant-white to-elegant-light-silver px-4 sm:px-8 relative"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1.5 }}
    >
      <motion.div
        className="text-center"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 1 }}
      >
        <h1 className="text-4xl md:text-6xl font-serif text-primary mb-4 tracking-wide">{weddingData.hero.title}</h1>
        <div className="w-32 h-px bg-gradient-to-r from-transparent via-primary to-transparent mx-auto my-6"></div>
        <h2 className="text-2xl md:text-3xl font-script text-elegant-charcoal mb-8 tracking-wider">{weddingData.hero.coupleNames}</h2>
        
        <motion.div
          className="space-y-2 text-elegant-charcoal"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 1, duration: 0.8 }}
        >
          <p className="text-lg font-elegant tracking-wide">{weddingData.hero.date}</p>
          <p className="text-base font-elegant opacity-80">Pukul {weddingData.hero.time}</p>
        </motion.div>

        <motion.button
          className="btn btn-primary mt-8 rounded-full px-8 font-elegant tracking-wider text-elegant-white border-2 border-primary hover:bg-transparent hover:text-primary transition-all duration-300"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={scrollToQuote}
        >
          Buka Undangan
        </motion.button>
      </motion.div>
    </motion.section>
  );
}

// Komponen Couple Section
function CoupleSection() {
  const { ref, isInView } = useScrollAnimation();

  return (
    <section ref={ref} className="py-16 px-4 sm:px-8 bg-base-100">
      <div className="max-w-md mx-auto">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-serif text-primary mb-4">Mempelai</h2>
          <div className="divider divider-primary w-24 mx-auto"></div>
        </motion.div>

        <div className="space-y-12">
          {/* Mempelai Pria */}
          <motion.div
            className="card bg-base-200 shadow-lg"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            <div className="card-body text-center">
              <div className="avatar mb-4">
                <div className="w-32 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
                  <img src={weddingData.couple.groom.photo} alt="Mempelai Pria" />
                </div>
              </div>
              <h3 className="card-title text-primary justify-center">{weddingData.couple.groom.name}</h3>
              <p className="text-sm text-neutral">Putra dari</p>
              <p className="text-sm font-medium">{weddingData.couple.groom.parents}</p>
            </div>
          </motion.div>

          {/* Ornamen Tengah */}
          <motion.div
            className="text-center"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <div className="text-6xl text-primary">💕</div>
          </motion.div>

          {/* Mempelai Wanita */}
          <motion.div
            className="card bg-base-200 shadow-lg"
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            <div className="card-body text-center">
              <div className="avatar mb-4">
                <div className="w-32 rounded-full ring ring-primary ring-offset-base-100 ring-offset-2">
                  <img src={weddingData.couple.bride.photo} alt="Mempelai Wanita" />
                </div>
              </div>
              <h3 className="card-title text-primary justify-center">{weddingData.couple.bride.name}</h3>
              <p className="text-sm text-neutral">Putri dari</p>
              <p className="text-sm font-medium">{weddingData.couple.bride.parents}</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Komponen Event Details
function EventSection() {
  const { ref, isInView } = useScrollAnimation();
  const openMaps = () => {
    window.open(weddingData.maps.url, "_blank");
  }

  return (
    <section ref={ref} className="py-16 px-4 sm:px-8 bg-secondary/10">
      <div className="max-w-md mx-auto">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-serif text-primary mb-4">Acara</h2>
          <div className="divider divider-primary w-24 mx-auto"></div>
        </motion.div>

        <div className="space-y-8">
          {weddingData.events.map((event, index) => (
            <motion.div
              key={index}
              className="card bg-base-100 shadow-lg"
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.2, duration: 0.8 }}
            >
              <div className="card-body text-center">
                <h3 className="card-title text-primary justify-center">{event.type}</h3>
                <div className="space-y-2 text-neutral">
                  <p>📅 {event.date}</p>
                  <p>⏰ {event.time}</p>
                  <p>📍 {event.venue}</p>
                  <p className="text-sm">{event.address}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="text-center mt-8"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <button className="btn btn-primary rounded-full px-8" onClick={openMaps}>
            📍 Buka Maps
          </button>
        </motion.div>
      </div>
    </section>
  );
}

// Komponen Story Section
function StorySection() {
  const { ref, isInView } = useScrollAnimation();

  return (
    <section ref={ref} className="py-16 px-4 sm:px-8 bg-gradient-to-b from-accent/5 to-secondary/10">
      <div className="max-w-md mx-auto">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-serif text-primary mb-4">Our Story</h2>
          <div className="divider divider-primary w-24 mx-auto"></div>
          <p className="text-neutral text-sm">Perjalanan cinta kami</p>
        </motion.div>

        <div className="space-y-8">
          {weddingData.story.map((step, index) => (
            <motion.div
              key={index}
              className="relative"
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: index * 0.2, duration: 0.8 }}
            >
              {/* Timeline Line */}
              {index < weddingData.story.length - 1 && (
                <div className="absolute left-1/2 top-20 w-0.5 h-16 bg-primary/30 transform -translate-x-1/2 z-0"></div>
              )}
              
              <div className={`card bg-gradient-to-r ${step.color} shadow-lg relative z-10`}>
                <div className="card-body text-center p-6">
                  {/* Icon */}
                  <motion.div
                    className="text-4xl mb-3"
                    initial={{ scale: 0 }}
                    animate={isInView ? { scale: 1 } : {}}
                    transition={{ delay: index * 0.2 + 0.3, duration: 0.5 }}
                  >
                    {step.icon}
                  </motion.div>
                  
                  {/* Title & Date */}
                  <h3 className="text-lg font-bold text-primary mb-1">{step.title}</h3>
                  <div className="badge badge-primary badge-sm mb-3">{step.date}</div>
                  
                  {/* Description */}
                  <p className="text-sm text-neutral leading-relaxed">{step.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Closing Message */}
        <motion.div
          className="text-center mt-12 p-6 bg-base-100 rounded-lg shadow-lg"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
        >
          <div className="text-2xl mb-3">🌟</div>
          <p className="text-sm text-neutral italic">
            "Cinta sejati tidak pernah berakhir. Cinta yang berakhir bukanlah cinta sejati."
          </p>
          <p className="text-xs text-primary mt-2 font-medium">- Andi & Sari</p>
        </motion.div>
      </div>
    </section>
  );
}

// Komponen Footer
function FooterSection() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gradient-to-t from-elegant-charcoal to-elegant-black text-elegant-white py-8 px-4 sm:px-8">
      <div className="max-w-md mx-auto text-center">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <h3 className="text-2xl font-serif mb-4 text-primary">Terima Kasih</h3>
          <p className="mb-4 font-elegant opacity-90">{weddingData.footer.thankYouMessage}</p>
          
          {/* Tombol Back to Top */}
          <motion.button
            className="btn btn-circle btn-primary mb-4 border-2 hover:bg-transparent hover:text-primary"
            onClick={scrollToTop}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            ⬆️
          </motion.button>
          
          <div className="w-24 h-px bg-gradient-to-r from-transparent via-elegant-silver to-transparent mx-auto my-4"></div>
          <p className="text-sm opacity-75 font-elegant">{weddingData.footer.signature}</p>
          <p className="text-xs opacity-50 mt-2 font-elegant">{weddingData.footer.madeWithLove}</p>
        </motion.div>
      </div>
    </footer>
  );
}

export function App() {
  const [isPlaying, setIsPlaying] = useState(false);

  const toggleMusic = () => {
    setIsPlaying(!isPlaying);
    // Implementasi audio player bisa ditambahkan di sini
  };

  const shareInvitation = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: weddingData.sharing.title,
          text: weddingData.sharing.text,
          url: window.location.href
        });
        // Share berhasil - tidak perlu alert
      } catch (error) {
        // Handle berbagai jenis error
        if (error instanceof Error) {
          if (error.name === 'AbortError') {
            // User membatalkan share - tidak perlu menampilkan error
            console.log('Share dibatalkan oleh user');
            return;
          }
          
          if (error.name === 'NotAllowedError') {
            console.log('Share tidak diizinkan');
            // Fallback ke clipboard
            fallbackToClipboard();
            return;
          }
          
          // Error lainnya
          console.log('Share error:', error.message);
          fallbackToClipboard();
        }
      }
    } else {
      // Browser tidak support Web Share API
      fallbackToClipboard();
    }
  };

  const fallbackToClipboard = () => {
    try {
      navigator.clipboard.writeText(window.location.href);
      alert(weddingData.sharing.copyMessage);
    } catch (clipboardError) {
      // Fallback manual jika clipboard juga gagal
      const textArea = document.createElement('textarea');
      textArea.value = window.location.href;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert(weddingData.sharing.copyMessage);
    }
  };

  return (
    <div className="min-h-screen w-full wedding-container bg-elegant-white font-elegant" data-theme="elegant">
      <HeroSection />
      <QuoteSection />
      <CoupleSection />
      <CountdownTimer />
      <EventSection />
      <StorySection />
      <GallerySection />
      <RSVPWishesSection />
      <FooterSection />
      
      {/* Global Floating Buttons */}
      <div className="floating-buttons">
        <motion.div
          className="flex flex-col gap-3"
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 2, duration: 0.8 }}
        >
          {/* Music Button */}
          <motion.button
            className={`btn btn-circle shadow-lg ${isPlaying ? 'btn-secondary' : 'btn-primary'} border-2 text-lg`}
            onClick={toggleMusic}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            animate={isPlaying ? { rotate: 360 } : { rotate: 0 }}
            transition={isPlaying ? { duration: 2, repeat: Infinity, ease: "linear" } : {}}
          >
            {isPlaying ? "🎵" : "🎶"}
          </motion.button>

          {/* Share Button */}
          <motion.button
            className="btn btn-circle btn-accent shadow-lg border-2 text-elegant-white hover:text-elegant-charcoal text-lg"
            onClick={shareInvitation}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            📤
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
}

export default App;
